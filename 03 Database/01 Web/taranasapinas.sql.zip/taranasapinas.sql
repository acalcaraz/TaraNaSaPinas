-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2018 at 01:16 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taranasapinas`
--

-- --------------------------------------------------------

--
-- Table structure for table `agencies`
--

CREATE TABLE `agencies` (
  `id` int(11) NOT NULL,
  `agency_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agency_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agency_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agency_contact` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agency_email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agency_permit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agency_info` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agency_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agency_rating` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `agency_logo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agencies`
--

INSERT INTO `agencies` (`id`, `agency_status`, `agency_name`, `agency_address`, `agency_contact`, `agency_email`, `agency_permit`, `agency_info`, `agency_url`, `agency_rating`, `created_at`, `updated_at`, `user_id`, `agency_logo`) VALUES
(2, 'Approved', 'APC Travel and Tours', '3 Humabon Place, Magallanes, Makati City', '+639997654321', 'mail@apc.edu.ph', '123-456-789-0', 'We are APC Travel and Tours.', 'www.apc.edu.ph', 5, NULL, NULL, 2, 'no_image.png'),
(4, 'Approved', '305 Travel & Tours, Inc.', 'Unit 1406, The One Executive Office Bldg., No. 5 West Avenue, Nayon Kaunlaran Quezon City', '+6324105272', 'inquiry@305travelandtours.com', '456-987-123-0', 'We are 305 Travel & Tours, Inc.', 'http://www.305travelandtours.com', 4, NULL, NULL, 4, 'no_image.png'),
(5, 'Pending', 'Access Travel and Tours, Inc.', 'Unit 8, 2nd Floor, 641 CIFRA Bldg., Boni Avenue, Mandaluyong City', '+639173511279', 'inquiry@travelwithaccess.com', '543-986-218-7', 'We are Access Travel and Tours, Inc.', 'http://www.travelwithaccess.com', 0, NULL, NULL, 5, 'no_image.png'),
(6, 'Approved', 'Wayfair Tours, Inc.', 'G/F Don Jacinto Bldg., 141 Salcedo St. corner Dela Rosa St., Legaspi Village, Makati City', '+639178474317', 'info@wayfairtours.com.ph', '333-649-875-6', 'We are Wayfair Tours, Inc.', 'http://www.wayfairtours.com.ph', 4, NULL, NULL, 6, 'no_image.png');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(10) UNSIGNED NOT NULL,
  `book_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_price` double(8,2) NOT NULL,
  `book_start` date NOT NULL,
  `book_end` date NOT NULL,
  `book_pax` int(11) NOT NULL,
  `book_fname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_lname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_contact` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_id` int(11) NOT NULL,
  `agency_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `book_status`, `book_price`, `book_start`, `book_end`, `book_pax`, `book_fname`, `book_lname`, `book_email`, `book_contact`, `deal_id`, `agency_id`, `created_at`, `updated_at`, `user_id`) VALUES
(1, 'Pending', 5000.00, '2018-04-18', '2018-04-20', 2, 'Anna', 'Alcaraz', 'acalcaraz@student.apc.edu.ph', '8220429', 1, 2, NULL, NULL, 2),
(2, 'Processing', 12500.00, '2018-04-30', '2018-05-02', 5, 'Justin', 'Besmano', 'jvbesmano@student.apc.edu.ph', '09998935009', 1, 2, NULL, NULL, 8),
(3, 'Complete', 5000.00, '2018-04-26', '2018-04-28', 2, 'Sammy', 'Angot', 'smangot@apc.edu.ph', '09198845654', 1, 2, NULL, NULL, 7),
(4, 'Processing', 8120.00, '2018-06-12', '2018-06-14', 2, 'Job', 'Brioso', 'jgbrioso@student.apc.edu.ph', '09998845653', 2, 6, NULL, NULL, 9),
(5, 'Pending', 8510.00, '2018-12-31', '2019-01-02', 2, 'Sammy', 'Angot', 'smangot@student.apc.edu.ph', '09998845654', 4, 2, NULL, NULL, 7),
(6, 'Pending', 4255.00, '2018-10-31', '2018-11-02', 1, 'Job', 'Brioso', 'jgbrioso@student.apc.edu.ph', '09198935009', 4, 2, NULL, NULL, 9),
(7, 'Processing', 4255.00, '2018-05-13', '2018-05-15', 1, 'Antonio', 'Lu', 'amlu@student.apc.edu.ph', '09998845654', 4, 2, NULL, NULL, 10);

-- --------------------------------------------------------

--
-- Table structure for table `deals`
--

CREATE TABLE `deals` (
  `id` int(10) UNSIGNED NOT NULL,
  `deal_location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_price` double(6,2) NOT NULL,
  `deal_sellstartdate` date DEFAULT NULL,
  `deal_sellenddate` date DEFAULT NULL,
  `deal_startdate` date NOT NULL,
  `deal_enddate` date NOT NULL,
  `deal_inclusions` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_exclusions` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_rating` int(11) NOT NULL,
  `agency_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deal_img1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_img2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_img3` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_img4` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `deals`
--

INSERT INTO `deals` (`id`, `deal_location`, `deal_price`, `deal_sellstartdate`, `deal_sellenddate`, `deal_startdate`, `deal_enddate`, `deal_inclusions`, `deal_exclusions`, `deal_rating`, `agency_id`, `created_at`, `updated_at`, `deal_img1`, `deal_img2`, `deal_img3`, `deal_img4`, `user_id`) VALUES
(1, 'Bohol', 2500.00, '2018-04-18', '2018-04-30', '2018-04-18', '2018-04-30', 'Bed and Breakfast', 'Transportation', 0, 2, NULL, NULL, 'bohol_1523995618.jpg', 'bohol2_1523995618.jpg', 'no_image.png', 'no_image.png', 2),
(2, 'Bohol', 4060.00, '2018-04-01', '2018-06-30', '2018-04-01', '2018-07-31', '• 2 Nights Hotel Accommodation on 3* Hotel • Daily hotel breakfast (Day 2- 3) • Private roundtrip airport transfer • Choco Countryside Tour with buffet lunch • All tour entrance fees • Private transportation during tours with driver guide', '• Domestic Airfare, Taxes, Terminal, Fees & Taxes  • Meals and/or beverages during tours • Tipping for the tour guide/driver (Non-mandatory) • Personal and other expenses not mentioned in the inclusions', 4, 6, NULL, NULL, 'no_image.png', 'no_image.png', 'no_image.png', 'no_image.png', 6),
(3, 'Bohol', 7290.00, '2018-04-01', '2018-12-31', '2018-04-01', '2018-12-31', '• 2 Nights Hotel Accommodation on 5* Hotel • Daily hotel breakfast (Day 2- 3) • Private roundtrip airport transfer • Choco Countryside Tour with buffet lunch • All tour entrance fees • Private transportation during tours with driver guide', '• Domestic Airfare, Taxes, Terminal, Fees & Taxes  • Meals and/or beverages during tours • Tipping for the tour guide/driver (Non-mandatory) • Personal and other expenses not mentioned in the inclusions', 4, 6, NULL, NULL, 'no_image.png', 'no_image.png', 'no_image.png', 'no_image.png', 6),
(4, 'Palawan', 4255.00, '2018-04-01', '2018-12-31', '2018-05-01', '2019-05-31', '• 2 Nights Hotel Accommodation on 3* hotel • Daily hotel breakfast (Day 2- 3) • Seat-in-Coach roundtrip airport transfer • Puerto Princesa City Tour with snacks • Underground River tour with lunch • All tour entrance fees', '• Domestic Airfare, Taxes, Terminal, Fees & Taxes  • Meals and/or beverages during tours', 5, 2, NULL, NULL, 'no_image.png', 'no_image.png', 'no_image.png', 'no_image.png', 2),
(5, 'Boracay', 5600.00, '2018-04-01', '2019-05-31', '2018-05-01', '2019-12-31', '• 2 Nights Hotel Accommodation on 3* Hotel • Daily hotel breakfast (Day 2- 3) • Seat-in-Coach roundtrip land & boat airport transfer • Boracay Island Hopping with seafood buffet lunch', '• Domestic Airfare, Taxes, Terminal, Fees & Taxes  • Meals and/or beverages during tours • Tipping for the tour guide/driver (Non-mandatory)', 3, 2, NULL, NULL, 'no_image.png', 'no_image.png', 'no_image.png', 'no_image.png', 2);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(10) UNSIGNED NOT NULL,
  `fb_date` date NOT NULL,
  `fb_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fb_rating` int(11) NOT NULL,
  `agency_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `fb_date`, `fb_text`, `fb_rating`, `agency_id`, `created_at`, `updated_at`, `user_id`) VALUES
(1, '2018-04-18', 'Good job.', 5, 2, NULL, NULL, 10),
(2, '2018-04-08', 'I would like to commend the customer service of your company. My booking was processed in a matter of days.', 4, 2, NULL, NULL, 9),
(3, '0000-00-00', 'The company was unable to give updates to the status of my booking. Service is very slow. The agency took months to book my trip.', 1, 6, NULL, NULL, 8),
(4, '2018-04-10', 'The agency took months to process my booking.', 1, 6, NULL, NULL, 3),
(5, '2018-04-01', 'The travel deals your company offers are the most affordable from what I\'ve seen. Keep up the good work.', 5, 2, NULL, NULL, 7);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_03_01_183756_create_deals_table', 2),
(4, '2018_03_03_032550_create_agencies_table', 2),
(5, '2018_03_09_215709_add_user_id_to_agencies_table', 2),
(6, '2018_03_10_012111_add_agency_logo_to_agencies_table', 2),
(7, '2018_03_10_021036_add_deal_images_to_deals_table', 2),
(8, '2018_04_02_223213_add_user_type_to_users_table', 2),
(9, '2018_04_06_085524_create_bookings_table', 2),
(10, '2018_04_13_073925_create_feedback_table', 2),
(11, '2018_04_17_171024_add_user_id_to_deals_table', 2),
(12, '2018_04_17_172307_add_user_id_to_bookings_table', 2),
(13, '2018_04_17_173016_add_user_id_to_feedbacks_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`, `remember_token`, `created_at`, `updated_at`, `user_type`) VALUES
(1, 'acalcaraz@student.apc.edu.ph', '$2y$10$1DshJmoGMs1VVWroi5byBOPbhPVVZXecR8ZCqLYj1cZ/pSOJsYdTa', 'Anna Alcaraz', '6yA3FX5I33Puz1JSWCZzZ2FLl5gv67OB3H79f2h7g087fkmlTb4HJ6XA9bgq', '2018-04-17 11:23:20', '2018-04-17 11:23:20', 'System Administrator'),
(2, 'mcespinas@student.apc.edu.ph', '$2y$10$/lUBZguc1BFv1gLLXmhNsu3mLZXiqe1Aj9MrAsUo5w6FDl6LtZWrm', 'Fevy Espinas', 'okxQAzeuyImGWrFR0wgYCmOXk037DPqYBzuC0DUpA5cMiOLVGieyz53c7Pvd', '2018-04-17 11:23:53', '2018-04-17 11:23:53', 'Travel Agency'),
(3, 'racamama@student.apc.edu.ph', '$2y$10$QYiltHpFWgc7lLMMlTMyCe5iSFTbllHYUG6JaCoD7rx4.AAP6Tj9m', 'Snow Camama', '0kADKJlYlFjyPkcoqI9MVjiexhoc8lYdrcNhCQaZGCuYgpoYh2TfbjcqIvEK', '2018-04-17 11:24:21', '2018-04-17 11:24:21', 'Traveler'),
(4, 'annalynn.alcaraz@gmail.com', '$2y$10$o7xulp8XnDUq3HHmKria.eIZVUux83z4fFbhDmRvDSYVpogLwyV2S', 'Anna Lynn Alcaraz', 'luWbrxdW5s1JNcZ7w5YVp1MIJzjJ0eUTFXp2Om8JoYFppEQBszF1UTNjPUhW', '2018-04-17 15:12:55', '2018-04-17 15:12:55', 'Travel Agency'),
(5, 'annalynn_0513@yahoo.com', '$2y$10$SSlGHLC9LMEqTA9mIEQUduHDoHswQTukQsiV92MVh.qXOS/ihRJfa', 'Anna Lynn Alcaraz', '6cl157CDHXjNFSpmR3WFKGvuIZlFiy26WfAQqdKwMZo5J46AXIO5k2E5XC7W', '2018-04-17 15:53:52', '2018-04-17 15:53:52', 'Travel Agency'),
(6, 'annalynn.0513@gmail.com', '$2y$10$eWnJ6MKBOB.9oS/kpHWtFOz5pSdtAJdoieOrN3gwCbeg7UmPK230q', 'Anna Lynn Alcaraz', 'h66QqrOrcrS8DfZgB3fDNwHuEECj7cuwdQzL7JzbwJ1UmT2G5d7kiyyKXBSc', '2018-04-17 15:54:26', '2018-04-17 15:54:26', 'Travel Agency'),
(7, 'smangot@student.apc.edu.ph', '$2y$10$pIhwxnZYz0H0FF4lq7cRMOw9IkiiH2nmaQk4x5EUBNNWbjQ344hoa', 'Sammy Angot', 'ItVK8h8BHODSGkXb3HgOnJrW5EMsMbhURejrLkOE0MMKfzTX6XU6xr9ZMRD1', '2018-04-17 16:50:00', '2018-04-17 16:50:00', 'Traveler'),
(8, 'jvbesmano@student.apc.edu.ph', '$2y$10$gR9YRtxEd8J7gDwVIdgQC.6eXhOqy9aFbq43SGP89/F8EZxxoxJg2', 'Justin Besmano', '5YR5AmT75bNdGDfBTimYkaRVD8UTiZOSEQ1jleZ3EFtRGKnspWIpX8ceiSr4', '2018-04-17 16:50:36', '2018-04-17 16:50:36', 'Traveler'),
(9, 'jgbrioso@student.apc.edu.ph', '$2y$10$zf9z4yadC6C.yJReiLhTxeOQlsNQpoyrjMvaAT8px74fUjaxWLFfG', 'Job Brioso', 'Nj2YDRqomoHryZmHS9kdn4rZR6JxTdMCcgJSWSiRedHBvfjq42zvni5SEu4n', '2018-04-17 16:51:03', '2018-04-17 16:51:03', 'Traveler'),
(10, 'amlu@student.apc.edu.ph', '$2y$10$MEBt0OccPZxQiJkFjIyVDeauRoh4ISIscSn5hWhD6i78CDHVQ7rbO', 'Antonio Lu', 'akQeq9CQCb5YKSIyaZdFCzINhZYj7KURqUCL97YOjGspqfJScYEWykwCJypA', '2018-04-17 16:51:38', '2018-04-17 16:51:38', 'Traveler');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agencies`
--
ALTER TABLE `agencies`
  ADD UNIQUE KEY `agencies_id_unique` (`id`),
  ADD KEY `agencies_user_id_foreign` (`user_id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bookings_id_unique` (`id`),
  ADD KEY `bookings_user_id_foreign` (`user_id`);

--
-- Indexes for table `deals`
--
ALTER TABLE `deals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `deals_id_unique` (`id`),
  ADD KEY `deals_user_id_foreign` (`user_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `feedback_id_unique` (`id`),
  ADD KEY `feedback_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `deals`
--
ALTER TABLE `deals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `agencies`
--
ALTER TABLE `agencies`
  ADD CONSTRAINT `agencies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `deals`
--
ALTER TABLE `deals`
  ADD CONSTRAINT `deals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
